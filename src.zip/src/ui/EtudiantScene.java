package ui;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;
import models.Etudiant;
import models.MenuJour;
import models.Plat;
import models.Reservation;
import services.MenuService;
import services.ReservationService;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EtudiantScene {
    private Scene scene;
    private Etudiant etudiant;
    private MenuService menuService;
    private ReservationService reservationService;
    private Runnable logoutCallback;
    private TabPane tabPane;

    public EtudiantScene(Etudiant etudiant, MenuService menuService, ReservationService reservationService,
                         Runnable logoutCallback) {
        this.etudiant = etudiant;
        this.menuService = menuService;
        this.reservationService = reservationService;
        this.logoutCallback = logoutCallback;
        this.scene = createScene();
    }

    private Scene createScene() {
        BorderPane root = new BorderPane();
        root.getStyleClass().add("border-pane");

        // Barre supérieure
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Contenu principal
        VBox mainContent = createMainContent();
        root.setCenter(mainContent);

        return new Scene(root, 900, 700);
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.getStyleClass().add("top-bar");
        topBar.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(topBar, javafx.scene.layout.Priority.ALWAYS);

        Label titleLabel = new Label("Menu Étudiant - " + etudiant.getPrenom() + " " + etudiant.getNom());
        titleLabel.getStyleClass().add("title-label");
        HBox.setHgrow(titleLabel, javafx.scene.layout.Priority.ALWAYS);

        Button logoutButton = new Button("Déconnexion");
        logoutButton.getStyleClass().addAll("button", "button-danger");
        logoutButton.setOnAction(e -> logoutCallback.run());

        topBar.getChildren().addAll(titleLabel, logoutButton);
        return topBar;
    }

    private VBox createMainContent() {
        VBox mainContent = new VBox(15);
        mainContent.setPadding(new Insets(20));
        mainContent.getStyleClass().add("vbox");

        // Onglets
        tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        tabPane.getTabs().addAll(
            createProfileTab(),
            createMenuTab(),
            createReservationTab(),
            createMyReservationsTab(),
            createRatingTab()
        );
        tabPane.getStyleClass().add("tab-pane");

        mainContent.getChildren().add(tabPane);
        return mainContent;
    }
    
    private void refreshTabContent() {
        // Recharge le contenu de tous les onglets pour la mise à jour dynamique
        tabPane.getTabs().set(0, createProfileTab());
        tabPane.getTabs().set(1, createMenuTab());
        tabPane.getTabs().set(2, createReservationTab());
        tabPane.getTabs().set(3, createMyReservationsTab());
        tabPane.getTabs().set(4, createRatingTab());
    }

    // --- Onglet Profil ---
    private Tab createProfileTab() {
        Tab tab = new Tab();
        tab.setText("Profil");
        tab.setClosable(false);

        VBox content = new VBox(20);
        content.setPadding(new Insets(30));
        content.getStyleClass().add("vbox");
        content.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Informations de l'Étudiant");
        title.getStyleClass().add("subtitle-label");

        VBox infoBox = new VBox(10);
        infoBox.getStyleClass().add("login-card");
        infoBox.setMaxWidth(400);

        infoBox.getChildren().add(createProfileRow("Nom:", etudiant.getNom()));
        infoBox.getChildren().add(createProfileRow("Prénom:", etudiant.getPrenom()));
        infoBox.getChildren().add(createProfileRow("Email:", etudiant.getEmail()));
        infoBox.getChildren().add(createProfileRow("Année d'Inscription:", String.valueOf(etudiant.getAnneeInscription())));
        infoBox.getChildren().add(createProfileRow("Type:", etudiant.getType()));

        content.getChildren().addAll(title, infoBox);
        tab.setContent(content);
        return tab;
    }

    private HBox createProfileRow(String label, String value) {
        HBox row = new HBox(10);
        row.getStyleClass().add("profile-row");
        row.setAlignment(Pos.CENTER_LEFT);
        Label labelNode = new Label(label);
        labelNode.setStyle("-fx-font-weight: bold;");
        Label valueNode = new Label(value);
        row.getChildren().addAll(labelNode, valueNode);
        return row;
    }

    // --- Onglet Menu ---
    private Tab createMenuTab() {
        Tab tab = new Tab();
        tab.setText("Consulter le Menu");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        List<MenuJour> menu = menuService.getMenuDeLaSemaine();

        Label titleLabel = new Label("Menu de la Semaine");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);

        if (menu.isEmpty()) {
            Label noMenuLabel = new Label("Aucun menu n'a été créé pour cette semaine.");
            noMenuLabel.getStyleClass().add("alert-error");
            content.getChildren().add(noMenuLabel);
        } else {
            VBox menuDisplay = new VBox(15);
            menuDisplay.getStyleClass().add("vbox");

            for (MenuJour menuJour : menu) {
                VBox dayBox = new VBox(5);
                dayBox.getStyleClass().add("login-card");
                dayBox.setStyle("-fx-padding: 10;");

                Label dayLabel = new Label(menuJour.getJour().toString());
                dayLabel.getStyleClass().add("label");
                dayLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2ecc71;");
                dayBox.getChildren().add(dayLabel);

                // Utilisation de TableView pour la liste des plats
                TableView<Plat> table = new TableView<>();
                table.getStyleClass().add("table-view");
                table.setItems(FXCollections.observableArrayList(menuJour.getPlats()));
                table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

                TableColumn<Plat, String> nameCol = new TableColumn<>("Plat");
                nameCol.setCellValueFactory(new PropertyValueFactory<>("nom"));

                TableColumn<Plat, String> ingredientsCol = new TableColumn<>("Ingrédients");
                ingredientsCol.setCellValueFactory(new PropertyValueFactory<>("aliments"));

                table.getColumns().addAll(nameCol, ingredientsCol);
                table.setPrefHeight(menuJour.getPlats().size() * 30 + 30); // Ajuster la hauteur

                dayBox.getChildren().add(table);
                menuDisplay.getChildren().add(dayBox);
            }
            content.getChildren().add(menuDisplay);
        }

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        tab.setContent(scrollPane);
        return tab;
    }

    // --- Onglet Réservation ---
    private Tab createReservationTab() {
        Tab tab = new Tab();
        tab.setText("Réserver un Repas");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        Label titleLabel = new Label("Réserver un repas");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);

        List<MenuJour> menu = menuService.getMenuDeLaSemaine();

        if (menu.isEmpty()) {
            Label noMenuLabel = new Label("Aucun menu n'a été créé pour cette semaine. Impossible de réserver.");
            noMenuLabel.getStyleClass().add("alert-error");
            content.getChildren().add(noMenuLabel);
        } else {
            VBox reservationBox = new VBox(10);
            reservationBox.getStyleClass().add("login-card");
            
            Label selectDateLabel = new Label("1. Sélectionner la date de réservation:");
            selectDateLabel.getStyleClass().add("label");

            DatePicker datePicker = new DatePicker(LocalDate.now().plusDays(1));
            datePicker.getStyleClass().add("date-picker");
            
            Label selectPlatLabel = new Label("2. Sélectionner le plat:");
            selectPlatLabel.getStyleClass().add("label");
            
            ComboBox<Plat> platCombo = new ComboBox<>();
            platCombo.getStyleClass().add("combo-box");
            platCombo.setPromptText("Plat du jour");
            platCombo.setDisable(true);

            Button reserveButton = new Button("Réserver");
            reserveButton.getStyleClass().addAll("button", "button-primary");
            reserveButton.setDisable(true);

            // Listener pour la sélection de la date
            datePicker.valueProperty().addListener((obs, oldVal, selectedDate) -> {
                platCombo.getItems().clear();
                platCombo.setDisable(true);
                reserveButton.setDisable(true);
                
                if (selectedDate != null && selectedDate.isAfter(LocalDate.now())) {
                    DayOfWeek day = selectedDate.getDayOfWeek();
                    Optional<MenuJour> menuJour = menuService.getMenuJour(day);
                    
                    if (menuJour.isPresent()) {
                        platCombo.setItems(FXCollections.observableArrayList(menuJour.get().getPlats()));
                        platCombo.setDisable(false);
                    } else {
                        showAlert(AlertType.WARNING, "Attention", "Le restaurant est fermé ce jour-là.");
                    }
                } else {
                    showAlert(AlertType.WARNING, "Attention", "Veuillez sélectionner une date future.");
                }
            });
            
            // Listener pour la sélection du plat
            platCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, plat) -> {
                reserveButton.setDisable(plat == null);
            });

            // Logique de réservation
            reserveButton.setOnAction(e -> {
                LocalDate date = datePicker.getValue();
                Plat plat = platCombo.getSelectionModel().getSelectedItem();
                
                if (date == null || plat == null) {
                    showAlert(AlertType.ERROR, "Erreur", "Veuillez sélectionner une date et un plat.");
                    return;
                }
                
                if (reservationService.reservationExiste(etudiant.getEmail(), date.getDayOfWeek())) {
                    showAlert(AlertType.WARNING, "Attention", "Vous avez déjà une réservation pour ce jour.");
                    return;
                }
                
                try {
                    reservationService.reserver(etudiant.getEmail(), date.getDayOfWeek(), plat.getId());
                    showAlert(AlertType.INFORMATION, "Succès", "Réservation pour le " + date.getDayOfWeek().toString() + " (Plat: " + plat.getNom() + ") effectuée avec succès!");
                    
                    // Mise à jour dynamique des onglets
                    refreshTabContent();
                } catch (Exception ex) {
                    showAlert(AlertType.ERROR, "Erreur", "Erreur lors de la réservation: " + ex.getMessage());
                }
            });

            reservationBox.getChildren().addAll(
                selectDateLabel, datePicker,
                selectPlatLabel, platCombo,
                reserveButton
            );
            content.getChildren().add(reservationBox);
        }

        tab.setContent(content);
        return tab;
    }

    // --- Onglet Mes Réservations ---
    private Tab createMyReservationsTab() {
        Tab tab = new Tab();
        tab.setText("Mes Réservations");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        Label titleLabel = new Label("Historique de mes Réservations");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);

        List<Reservation> reservations = reservationService.getReservationsParEtudiant(etudiant.getEmail());

        if (reservations.isEmpty()) {
            Label noReservationsLabel = new Label("Vous n'avez aucune réservation.");
            noReservationsLabel.getStyleClass().add("label");
            content.getChildren().add(noReservationsLabel);
        } else {
            TableView<ReservationRow> table = new TableView<>();
            table.getStyleClass().add("table-view");
            table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

            TableColumn<ReservationRow, String> dayCol = new TableColumn<>("Jour");
            dayCol.setCellValueFactory(new PropertyValueFactory<>("day"));

            TableColumn<ReservationRow, String> platCol = new TableColumn<>("Plat Réservé");
            platCol.setCellValueFactory(new PropertyValueFactory<>("platNom"));

            TableColumn<ReservationRow, String> takenCol = new TableColumn<>("Repas Pris");
            takenCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().isMealTaken() ? "OUI" : "NON"));
            
            TableColumn<ReservationRow, String> ratedCol = new TableColumn<>("Noté");
            ratedCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getRating() != null ? "OUI" : "NON"));

            table.getColumns().addAll(dayCol, platCol, takenCol, ratedCol);

            List<ReservationRow> rows = reservations.stream().map(res -> {
                Optional<Plat> plat = menuService.getPlatParId(res.getPlatId());
                return new ReservationRow(
                    res.getJour().toString(),
                    res.isRepasPris(),
                    res.getNote() > 0 ? String.valueOf(res.getNote()) : null,
                    plat.map(Plat::getNom).orElse("Inconnu")
                );
            }).collect(Collectors.toList());

            table.setItems(FXCollections.observableArrayList(rows));
            content.getChildren().add(table);
        }

        tab.setContent(content);
        return tab;
    }

    // --- Onglet Notation ---
    private Tab createRatingTab() {
        Tab tab = new Tab();
        tab.setText("Noter un Repas");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        Label titleLabel = new Label("Noter un repas consommé");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);

        List<Reservation> toRate = reservationService.getReservationsParEtudiant(etudiant.getEmail()).stream()
                .filter(Reservation::isRepasPris)
                .filter(r -> r.getNote() == 0)
                .collect(Collectors.toList());

        if (toRate.isEmpty()) {
            Label noRateLabel = new Label("Aucun repas à noter pour le moment.");
            noRateLabel.getStyleClass().add("label");
            content.getChildren().add(noRateLabel);
        } else {
            VBox ratingBox = new VBox(10);
            ratingBox.getStyleClass().add("login-card");
            
            Label selectReservationLabel = new Label("Sélectionner le repas à noter:");
            selectReservationLabel.getStyleClass().add("label");
            
            ComboBox<Reservation> reservationCombo = new ComboBox<>();
            reservationCombo.getStyleClass().add("combo-box");
            reservationCombo.setPromptText("Repas consommé");
            
            reservationCombo.setItems(FXCollections.observableArrayList(toRate));
            reservationCombo.setCellFactory(lv -> new ListCell<Reservation>() {
                @Override
                protected void updateItem(Reservation item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        Optional<Plat> plat = menuService.getPlatParId(item.getPlatId());
                        setText(item.getJour().toString() + " - Plat: " + plat.map(Plat::getNom).orElse("Inconnu"));
                    }
                }
            });
            
            Label ratingLabel = new Label("Votre note (1 à 5):");
            ratingLabel.getStyleClass().add("label");
            
            Spinner<Integer> ratingSpinner = new Spinner<>(1, 5, 3);
            ratingSpinner.getStyleClass().add("spinner");
            ratingSpinner.setEditable(false);
            
            Button rateButton = new Button("Noter");
            rateButton.getStyleClass().addAll("button", "button-primary");
            rateButton.setDisable(true);
            
            reservationCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                rateButton.setDisable(newVal == null);
            });
            
            rateButton.setOnAction(e -> {
                Reservation selectedReservation = reservationCombo.getSelectionModel().getSelectedItem();
                int rating = ratingSpinner.getValue();
                
                if (selectedReservation != null) {
                    try {
                        reservationService.noterRepas(selectedReservation.getEmailEtudiant(), selectedReservation.getJour(), String.valueOf(rating));
                        showAlert(AlertType.INFORMATION, "Succès", "Repas noté " + rating + "/5 avec succès!");
                        
                        // Mise à jour dynamique des onglets
                        refreshTabContent();
                    } catch (Exception ex) {
                        showAlert(AlertType.ERROR, "Erreur", "Erreur lors de la notation: " + ex.getMessage());
                    }
                }
            });
            
            ratingBox.getChildren().addAll(
                selectReservationLabel, reservationCombo,
                ratingLabel, ratingSpinner,
                rateButton
            );
            content.getChildren().add(ratingBox);
        }

        tab.setContent(content);
        return tab;
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public Scene getScene() {
        return scene;
    }

    // Classe interne pour les lignes du tableau des réservations de l'étudiant
    public static class ReservationRow {
        private String day;
        private boolean mealTaken;
        private String rating;
        private String platNom;

        public ReservationRow(String day, boolean mealTaken, String rating, String platNom) {
            this.day = day;
            this.mealTaken = mealTaken;
            this.rating = rating;
            this.platNom = platNom;
        }

        public String getDay() { return day; }
        public boolean isMealTaken() { return mealTaken; }
        public String getRating() { return rating; }
        public String getPlatNom() { return platNom; }
    }
}
