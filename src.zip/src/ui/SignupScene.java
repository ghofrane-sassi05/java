package ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import services.UserService;

import java.util.function.Consumer;

public class SignupScene {
    private Scene scene;
    private Consumer<String> backToLoginCallback;
    private UserService userService;

    public SignupScene(Consumer<String> backToLoginCallback, UserService userService) {
        this.backToLoginCallback = backToLoginCallback;
        this.userService = userService;
        this.scene = createScene();
    }

    private Scene createScene() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(50));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("border-pane");
        root.getStyleClass().add("login-scene");

        // Titre
        Label titleLabel = new Label("Inscription Étudiant");
        titleLabel.getStyleClass().add("title-label");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        titleLabel.setStyle("-fx-text-fill: #333333;");

        Label subtitleLabel = new Label("Création de votre compte IHEC");
        subtitleLabel.getStyleClass().add("subtitle-label");

        // Formulaire d'inscription
        VBox formBox = new VBox(15);
        formBox.getStyleClass().add("login-card");
        formBox.setPadding(new Insets(30));
        formBox.setMaxWidth(400);

        Label emailLabel = new Label("Email IHEC:");
        emailLabel.getStyleClass().add("label");
        TextField emailField = new TextField();
        emailField.setPromptText("nom.prenom.2024@ihec.ucar.tn");
        emailField.getStyleClass().add("text-field");

        Label passwordLabel = new Label("Mot de passe:");
        passwordLabel.getStyleClass().add("label");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Choisissez un mot de passe");
        passwordField.getStyleClass().add("password-field");
        
        Label confirmPasswordLabel = new Label("Confirmer le mot de passe:");
        confirmPasswordLabel.getStyleClass().add("label");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirmez votre mot de passe");
        confirmPasswordField.getStyleClass().add("password-field");

        // Boutons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);

        Button signupButton = new Button("S'inscrire");
        signupButton.getStyleClass().addAll("button", "button-primary");
        
        Button backButton = new Button("Retour à la Connexion");
        backButton.getStyleClass().addAll("button", "button-danger");
        backButton.setOnAction(e -> backToLoginCallback.accept(""));

        buttonBox.getChildren().addAll(signupButton, backButton);

        formBox.getChildren().addAll(
                emailLabel, emailField,
                passwordLabel, passwordField,
                confirmPasswordLabel, confirmPasswordField,
                buttonBox
        );

        root.getChildren().addAll(titleLabel, subtitleLabel, formBox);

        // Logique d'inscription
        signupButton.setOnAction(e -> handleSignup(emailField.getText(), passwordField.getText(), confirmPasswordField.getText()));

        // Validation en temps réel
        Runnable updateButtonState = () -> {
            boolean isEmailValid = isValidEmail(emailField.getText().trim());
            boolean isPasswordPresent = !passwordField.getText().isEmpty();
            boolean isConfirmPasswordPresent = !confirmPasswordField.getText().isEmpty();
            
            signupButton.setDisable(!(isEmailValid && isPasswordPresent && isConfirmPasswordPresent));

            if (!emailField.getText().isEmpty() && !isEmailValid) {
                emailField.getStyleClass().add("invalid-field");
            } else {
                emailField.getStyleClass().remove("invalid-field");
            }
            
            if (!confirmPasswordField.getText().isEmpty() && !passwordField.getText().equals(confirmPasswordField.getText())) {
                confirmPasswordField.getStyleClass().add("invalid-field");
            } else {
                confirmPasswordField.getStyleClass().remove("invalid-field");
            }
        };

        emailField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
        confirmPasswordField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
        updateButtonState.run(); // Initial check

        return new Scene(root, 900, 700);
    }

    private void handleSignup(String email, String password, String confirmPassword) {
        email = email.trim();
        
        if (!isValidEmail(email)) {
            showAlert(AlertType.ERROR, "Erreur de format", "Veuillez entrer une adresse email IHEC valide (nom.prenom.annee@ihec.ucar.tn).");
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            showAlert(AlertType.ERROR, "Erreur de mot de passe", "Les mots de passe ne correspondent pas.");
            return;
        }
        
        if (password.length() < 4) {
            showAlert(AlertType.ERROR, "Erreur de mot de passe", "Le mot de passe doit contenir au moins 4 caractères.");
            return;
        }

        try {
            if (userService.creerCompteEtudiant(email, password)) {
                showAlert(AlertType.INFORMATION, "Succès", "Votre compte a été créé avec succès. Vous pouvez maintenant vous connecter.");
                backToLoginCallback.accept(email); // Retour à la page de connexion avec l'email pré-rempli
            } else {
                showAlert(AlertType.ERROR, "Erreur d'inscription", "Un compte avec cet email existe déjà ou l'email n'est pas au format attendu.");
            }
        } catch (Exception e) {
            showAlert(AlertType.ERROR, "Erreur système", "Une erreur inattendue est survenue: " + e.getMessage());
        }
    }

    private boolean isValidEmail(String email) {
        // Regex spécifique pour le format nom.prenom.annee@ihec.ucar.tn
        return email.matches("^[a-zA-Z]+\\.[a-zA-Z]+\\.\\d{4}@ihec\\.ucar\\.tn$");
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public Scene getScene() {
        return scene;
    }
}
