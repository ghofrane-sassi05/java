package ui;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;
import models.ChefPrincipal;
import models.MenuJour;
import models.Plat;
import models.Reservation;
import models.Etudiant;
import services.MenuService;
import services.ReservationService;
import services.UserService;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ChefScene {
    private Scene scene;
    private ChefPrincipal chef;
    private MenuService menuService;
    private ReservationService reservationService;
    private UserService userService;
    private Runnable logoutCallback;
    private TabPane tabPane;

    public ChefScene(ChefPrincipal chef, MenuService menuService, ReservationService reservationService,
                     UserService userService, Runnable logoutCallback) {
        this.chef = chef;
        this.menuService = menuService;
        this.reservationService = reservationService;
        this.userService = userService;
        this.logoutCallback = logoutCallback;
        this.scene = createScene();
    }

    private Scene createScene() {
        BorderPane root = new BorderPane();
        root.getStyleClass().add("border-pane");

        // Barre supérieure
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Contenu principal
        VBox mainContent = createMainContent();
        root.setCenter(mainContent);

        return new Scene(root, 900, 700);
    }

    private HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.getStyleClass().add("top-bar");
        topBar.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(topBar, javafx.scene.layout.Priority.ALWAYS);

        Label titleLabel = new Label("Menu Chef Principal - " + chef.getPrenom() + " " + chef.getNom());
        titleLabel.getStyleClass().add("title-label");
        HBox.setHgrow(titleLabel, javafx.scene.layout.Priority.ALWAYS);

        Button logoutButton = new Button("Déconnexion");
        logoutButton.getStyleClass().addAll("button", "button-danger");
        logoutButton.setOnAction(e -> logoutCallback.run());

        topBar.getChildren().addAll(titleLabel, logoutButton);
        return topBar;
    }

    private VBox createMainContent() {
        VBox mainContent = new VBox(15);
        mainContent.setPadding(new Insets(20));
        mainContent.getStyleClass().add("vbox");

        // Onglets
        tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        tabPane.getTabs().addAll(
            createMenuTab(),
            createReservationsTab(),
            createStatsTab(),
            createValidationTab(),
            createProfileTab()
        );
        tabPane.getStyleClass().add("tab-pane");

        mainContent.getChildren().add(tabPane);
        return mainContent;
    }
    
    private void refreshTabContent() {
        // Recharge le contenu de tous les onglets pour la mise à jour dynamique
        tabPane.getTabs().set(0, createMenuTab());
        tabPane.getTabs().set(1, createReservationsTab());
        tabPane.getTabs().set(2, createStatsTab());
        tabPane.getTabs().set(3, createValidationTab());
        tabPane.getTabs().set(4, createProfileTab());
    }

    // --- Onglet Profil ---
    private Tab createProfileTab() {
        Tab tab = new Tab();
        tab.setText("Profil");
        tab.setClosable(false);

        VBox content = new VBox(20);
        content.setPadding(new Insets(30));
        content.getStyleClass().add("vbox");
        content.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Informations du Chef Principal");
        title.getStyleClass().add("subtitle-label");

        VBox infoBox = new VBox(10);
        infoBox.getStyleClass().add("login-card");
        infoBox.setMaxWidth(400);

        infoBox.getChildren().add(createProfileRow("Nom:", chef.getNom()));
        infoBox.getChildren().add(createProfileRow("Prénom:", chef.getPrenom()));
        infoBox.getChildren().add(createProfileRow("Email:", chef.getEmail()));
        infoBox.getChildren().add(createProfileRow("Type:", chef.getType()));

        content.getChildren().addAll(title, infoBox);
        tab.setContent(content);
        return tab;
    }

    private HBox createProfileRow(String label, String value) {
        HBox row = new HBox(10);
        row.getStyleClass().add("profile-row");
        row.setAlignment(Pos.CENTER_LEFT);
        Label labelNode = new Label(label);
        labelNode.setStyle("-fx-font-weight: bold;");
        Label valueNode = new Label(value);
        row.getChildren().addAll(labelNode, valueNode);
        return row;
    }

    // --- Onglet Menu ---
    private Tab createMenuTab() {
        Tab tab = new Tab();
        tab.setText("Gérer le Menu");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        Label titleLabel = new Label("Menu de la Semaine");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);

        if (menuService.menuExiste()) {
            Label existingLabel = new Label("✓ Le menu de la semaine a déjà été créé et ne peut pas être modifié.");
            existingLabel.getStyleClass().add("alert-success");
            content.getChildren().add(existingLabel);

            // Afficher le menu existant avec TableView
            VBox menuDisplay = new VBox(15);
            menuDisplay.getStyleClass().add("vbox");

            for (MenuJour menuJour : menuService.getMenuDeLaSemaine()) {
                VBox dayBox = new VBox(5);
                dayBox.getStyleClass().add("login-card");
                dayBox.setStyle("-fx-padding: 10;");

                Label dayLabel = new Label(menuJour.getJour().toString());
                dayLabel.getStyleClass().add("label");
                dayLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2ecc71;");
                dayBox.getChildren().add(dayLabel);

                TableView<Plat> table = new TableView<>();
                table.getStyleClass().add("table-view");
                table.setItems(FXCollections.observableArrayList(menuJour.getPlats()));
                table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

                TableColumn<Plat, String> nameCol = new TableColumn<>("Plat");
                nameCol.setCellValueFactory(new PropertyValueFactory<>("nom"));

                TableColumn<Plat, String> ingredientsCol = new TableColumn<>("Ingrédients");
                ingredientsCol.setCellValueFactory(new PropertyValueFactory<>("aliments"));

                table.getColumns().addAll(nameCol, ingredientsCol);
                table.setPrefHeight(menuJour.getPlats().size() * 30 + 30);

                dayBox.getChildren().add(table);
                menuDisplay.getChildren().add(dayBox);
            }
            content.getChildren().add(menuDisplay);
        } else {
            Label noMenuLabel = new Label("Aucun menu n'a été créé. Remplissez le formulaire ci-dessous:");
            noMenuLabel.getStyleClass().add("label");
            content.getChildren().add(noMenuLabel);

            // Formulaire de création de menu
            VBox formBox = createMenuForm();
            content.getChildren().add(formBox);
        }

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        tab.setContent(scrollPane);
        return tab;
    }

    private VBox createMenuForm() {
        VBox formBox = new VBox(15);
        formBox.getStyleClass().add("login-card");

        List<DayOfWeek> days = Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                DayOfWeek.THURSDAY, DayOfWeek.FRIDAY);
        List<VBox> dayBoxes = new ArrayList<>();

        for (DayOfWeek day : days) {
            VBox dayBox = new VBox(10);
            dayBox.getStyleClass().add("login-card");
            dayBox.setStyle("-fx-padding: 10;");

            Label dayLabel = new Label(day.toString());
            dayLabel.getStyleClass().add("label");
            dayLabel.setStyle("-fx-font-weight: bold;");
            dayBox.getChildren().add(dayLabel);

            VBox dishesBox = new VBox(8);
            dishesBox.getStyleClass().add("vbox");

            // Ajouter 3 champs pour les plats
            for (int i = 0; i < 3; i++) {
                HBox dishRow = new HBox(10);
                TextField dishName = new TextField();
                dishName.setPromptText("Nom du plat (Tunisien)");
                dishName.getStyleClass().add("text-field");
                dishName.setPrefWidth(150);

                TextField dishIngredients = new TextField();
                dishIngredients.setPromptText("Ingrédients (séparés par des virgules)");
                dishIngredients.getStyleClass().add("text-field");
                dishIngredients.setPrefWidth(300);

                dishRow.getChildren().addAll(dishName, dishIngredients);
                dishesBox.getChildren().add(dishRow);
            }

            dayBox.getChildren().add(dishesBox);
            dayBoxes.add(dayBox);
            formBox.getChildren().add(dayBox);
        }

        Button submitButton = new Button("Créer le Menu");
        submitButton.getStyleClass().addAll("button", "button-primary");

        // Validation en temps réel: désactiver si au moins un plat n'est pas rempli pour chaque jour
        Runnable updateButtonState = () -> {
            boolean allDaysValid = true;
            for (VBox dayBox : dayBoxes) {
                VBox dishesBox = (VBox) dayBox.getChildren().get(1);
                boolean dayHasDish = false;
                for (javafx.scene.Node node : dishesBox.getChildren()) {
                    if (node instanceof HBox) {
                        HBox dishRow = (HBox) node;
                        TextField nameField = (TextField) dishRow.getChildren().get(0);
                        TextField ingredientsField = (TextField) dishRow.getChildren().get(1);
                        if (!nameField.getText().trim().isEmpty() && !ingredientsField.getText().trim().isEmpty()) {
                            dayHasDish = true;
                            break;
                        }
                    }
                }
                if (!dayHasDish) {
                    allDaysValid = false;
                    break;
                }
            }
            submitButton.setDisable(!allDaysValid);
        };

        // Ajouter des listeners à tous les champs de texte
        for (VBox dayBox : dayBoxes) {
            VBox dishesBox = (VBox) dayBox.getChildren().get(1);
            for (javafx.scene.Node node : dishesBox.getChildren()) {
                if (node instanceof HBox) {
                    HBox dishRow = (HBox) node;
                    TextField nameField = (TextField) dishRow.getChildren().get(0);
                    TextField ingredientsField = (TextField) dishRow.getChildren().get(1);
                    nameField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
                    ingredientsField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
                }
            }
        }
        updateButtonState.run(); // Vérification initiale

        submitButton.setOnAction(e -> handleCreateMenu(dayBoxes));

        formBox.getChildren().add(submitButton);
        return formBox;
    }

    private void handleCreateMenu(List<VBox> dayBoxes) {
        try {
            List<MenuJour> newMenu = new ArrayList<>();
            List<DayOfWeek> days = Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                    DayOfWeek.THURSDAY, DayOfWeek.FRIDAY);

            for (int i = 0; i < dayBoxes.size(); i++) {
                MenuJour menuJour = new MenuJour(days.get(i));
                VBox dayBox = dayBoxes.get(i);

                VBox dishesBox = (VBox) dayBox.getChildren().get(1);
                for (javafx.scene.Node node : dishesBox.getChildren()) {
                    if (node instanceof HBox) {
                        HBox dishRow = (HBox) node;
                        TextField nameField = (TextField) dishRow.getChildren().get(0);
                        TextField ingredientsField = (TextField) dishRow.getChildren().get(1);

                        String name = nameField.getText().trim();
                        String ingredients = ingredientsField.getText().trim();

                        if (!name.isEmpty() && !ingredients.isEmpty()) {
                            menuJour.ajouterPlat(new Plat(name, ingredients));
                        }
                    }
                }

                if (menuJour.getPlats().isEmpty()) {
                    showAlert(AlertType.ERROR, "Erreur", "Veuillez ajouter au moins un plat pour chaque jour.");
                    return;
                }
                newMenu.add(menuJour);
            }

            menuService.creerMenuDeLaSemaine(newMenu);
            showAlert(AlertType.INFORMATION, "Succès", "Menu créé avec succès!");

            // Mise à jour dynamique de l'onglet
            refreshTabContent();
        } catch (Exception ex) {
            showAlert(AlertType.ERROR, "Erreur", "Erreur lors de la création du menu: " + ex.getMessage());
        }
    }

    // --- Onglet Réservations du Jour ---
    private Tab createReservationsTab() {
        Tab tab = new Tab();
        tab.setText("Réservations du Jour");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        DayOfWeek today = LocalDate.now().getDayOfWeek();
        if (today == DayOfWeek.SATURDAY || today == DayOfWeek.SUNDAY) {
            Label closedLabel = new Label("Le restaurant est fermé le week-end.");
            closedLabel.getStyleClass().add("alert-error");
            content.getChildren().add(closedLabel);
        } else {
            Label dayLabel = new Label("Réservations pour le " + today.toString());
            dayLabel.getStyleClass().add("subtitle-label");
            content.getChildren().add(dayLabel);

            List<Reservation> reservations = reservationService.getReservationsParJour(today);

            if (reservations.isEmpty()) {
                Label noReservationsLabel = new Label("Aucune réservation pour aujourd'hui.");
                noReservationsLabel.getStyleClass().add("label");
                content.getChildren().add(noReservationsLabel);
            } else {
                // Tableau des réservations
                TableView<ReservationRow> table = new TableView<>();
                table.getStyleClass().add("table-view");
                table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

                TableColumn<ReservationRow, String> nameCol = new TableColumn<>("Nom");
                nameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getName()));

                TableColumn<ReservationRow, String> firstNameCol = new TableColumn<>("Prénom");
                firstNameCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getFirstName()));

                TableColumn<ReservationRow, String> emailCol = new TableColumn<>("Email");
                emailCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEmail()));
                
                TableColumn<ReservationRow, String> platCol = new TableColumn<>("Plat Réservé");
                platCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getPlatNom()));

                TableColumn<ReservationRow, String> takenCol = new TableColumn<>("Repas Pris");
                takenCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().isMealTaken() ? "OUI" : "NON"));

                table.getColumns().addAll(nameCol, firstNameCol, emailCol, platCol, takenCol);

                for (Reservation res : reservations) {
                    Optional<Etudiant> student = userService.getEtudiantParEmail(res.getEmailEtudiant());
                    Optional<Plat> plat = menuService.getPlatParId(res.getPlatId());
                    if (student.isPresent()) {
                        table.getItems().add(new ReservationRow(
                                student.get().getNom(),
                                student.get().getPrenom(),
                                res.getEmailEtudiant(),
                                res.isRepasPris(),
                                plat.map(Plat::getNom).orElse("Inconnu")
                        ));
                    }
                }

                content.getChildren().add(table);
            }
        }

        tab.setContent(content);
        return tab;
    }
    
    // --- Onglet Statistiques ---
    private Tab createStatsTab() {
        Tab tab = new Tab();
        tab.setText("Statistiques Réservations");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");
        
        Label titleLabel = new Label("Nombre de Réservations par Plat");
        titleLabel.getStyleClass().add("subtitle-label");
        content.getChildren().add(titleLabel);
        
        // Sélecteur de jour
        ComboBox<DayOfWeek> daySelector = new ComboBox<>();
        daySelector.getStyleClass().add("combo-box");
        daySelector.setItems(FXCollections.observableArrayList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY));
        daySelector.setPromptText("Sélectionner un jour");
        
        VBox statsDisplay = new VBox(10);
        statsDisplay.getStyleClass().add("vbox");
        
        daySelector.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, jour) -> {
            statsDisplay.getChildren().clear();
            if (jour != null) {
                Map<String, Long> stats = reservationService.getStatistiquesReservations(jour);
                
                if (stats.isEmpty()) {
                    statsDisplay.getChildren().add(new Label("Aucune réservation pour le " + jour.toString() + "."));
                } else {
                    TableView<StatRow> table = new TableView<>();
                    table.getStyleClass().add("table-view");
                    table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    
                    TableColumn<StatRow, String> platCol = new TableColumn<>("Plat Tunisien");
                    platCol.setCellValueFactory(new PropertyValueFactory<>("platNom"));
                    
                    TableColumn<StatRow, Long> countCol = new TableColumn<>("Nombre de Réservations");
                    countCol.setCellValueFactory(new PropertyValueFactory<>("count"));
                    
                    table.getColumns().addAll(platCol, countCol);
                    
                    List<StatRow> statRows = stats.entrySet().stream()
                            .map(entry -> new StatRow(entry.getKey(), entry.getValue()))
                            .collect(Collectors.toList());
                    
                    table.setItems(FXCollections.observableArrayList(statRows));
                    table.setPrefHeight(statRows.size() * 30 + 30);
                    statsDisplay.getChildren().add(table);
                }
            }
        });
        
        content.getChildren().addAll(daySelector, statsDisplay);
        tab.setContent(content);
        return tab;
    }

    // --- Onglet Validation ---
    private Tab createValidationTab() {
        Tab tab = new Tab();
        tab.setText("Valider Repas");
        tab.setClosable(false);

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.getStyleClass().add("vbox");

        DayOfWeek today = LocalDate.now().getDayOfWeek();
        if (today == DayOfWeek.SATURDAY || today == DayOfWeek.SUNDAY) {
            Label closedLabel = new Label("Le restaurant est fermé le week-end.");
            closedLabel.getStyleClass().add("alert-error");
            content.getChildren().add(closedLabel);
        } else {
            Label dayLabel = new Label("Valider la prise de repas pour le " + today.toString());
            dayLabel.getStyleClass().add("subtitle-label");
            content.getChildren().add(dayLabel);

            List<Reservation> reservations = reservationService.getReservationsParJour(today).stream()
                    .filter(r -> !r.isRepasPris())
                    .collect(Collectors.toList());

            if (reservations.isEmpty()) {
                Label noReservationsLabel = new Label("Aucune réservation à valider.");
                noReservationsLabel.getStyleClass().add("label");
                content.getChildren().add(noReservationsLabel);
            } else {
                ComboBox<String> studentCombo = new ComboBox<>();
                studentCombo.getStyleClass().add("combo-box");
                List<String> studentEmails = new ArrayList<>();

                for (Reservation res : reservations) {
                    Optional<Etudiant> student = userService.getEtudiantParEmail(res.getEmailEtudiant());
                    Optional<Plat> plat = menuService.getPlatParId(res.getPlatId());
                    if (student.isPresent()) {
                        String displayText = student.get().getNom() + " " + student.get().getPrenom() + " (" + res.getEmailEtudiant() + ") - Plat: " + plat.map(Plat::getNom).orElse("Inconnu");
                        studentCombo.getItems().add(displayText);
                        studentEmails.add(res.getEmailEtudiant());
                    }
                }

                HBox selectionBox = new HBox(10);
                selectionBox.setAlignment(Pos.CENTER_LEFT);
                Label selectLabel = new Label("Sélectionner un étudiant:");
                selectLabel.getStyleClass().add("label");
                selectionBox.getChildren().addAll(selectLabel, studentCombo);

                Button validateButton = new Button("Valider la prise de repas");
                validateButton.getStyleClass().addAll("button", "button-primary");

                // Validation en temps réel
                studentCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                    validateButton.setDisable(newVal == null);
                });
                validateButton.setDisable(true); // Désactiver par défaut

                validateButton.setOnAction(e -> {
                    int selectedIndex = studentCombo.getSelectionModel().getSelectedIndex();
                    if (selectedIndex >= 0) {
                        try {
                            reservationService.validerRepasPris(studentEmails.get(selectedIndex), today);
                            showAlert(AlertType.INFORMATION, "Succès", "Repas validé avec succès!");
                            // Mise à jour dynamique de l'onglet
                            refreshTabContent();
                        } catch (Exception ex) {
                            showAlert(AlertType.ERROR, "Erreur", "Erreur: " + ex.getMessage());
                        }
                    } else {
                        showAlert(AlertType.WARNING, "Erreur", "Veuillez sélectionner un étudiant.");
                    }
                });

                content.getChildren().addAll(selectionBox, validateButton);
            }
        }

        tab.setContent(content);
        return tab;
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public Scene getScene() {
        return scene;
    }

    // Classe interne pour les lignes du tableau des réservations
    public static class ReservationRow {
        private String name;
        private String firstName;
        private String email;
        private boolean mealTaken;
        private String platNom;

        public ReservationRow(String name, String firstName, String email, boolean mealTaken, String platNom) {
            this.name = name;
            this.firstName = firstName;
            this.email = email;
            this.mealTaken = mealTaken;
            this.platNom = platNom;
        }

        public String getName() { return name; }
        public String getFirstName() { return firstName; }
        public String getEmail() { return email; }
        public boolean isMealTaken() { return mealTaken; }
        public String getPlatNom() { return platNom; }
    }
    
    // Classe interne pour les lignes du tableau des statistiques
    public static class StatRow {
        private final SimpleStringProperty platNom;
        private final SimpleStringProperty count;

        public StatRow(String platNom, Long count) {
            this.platNom = new SimpleStringProperty(platNom);
            this.count = new SimpleStringProperty(String.valueOf(count));
        }

        public String getPlatNom() { return platNom.get(); }
        public String getCount() { return count.get(); }
    }
}
