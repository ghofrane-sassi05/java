package ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class LoginScene {
    private Scene scene;
    private BiConsumer<String, String> loginCallback;
    private Consumer<String> signupCallback;
    private String initialEmail = "";

    public LoginScene(BiConsumer<String, String> loginCallback, Consumer<String> signupCallback) {
        this.loginCallback = loginCallback;
        this.signupCallback = signupCallback;
        this.scene = createScene();
    }
    
    public LoginScene(BiConsumer<String, String> loginCallback, Consumer<String> signupCallback, String initialEmail) {
        this.loginCallback = loginCallback;
        this.signupCallback = signupCallback;
        this.initialEmail = initialEmail;
        this.scene = createScene();
    }

    private Scene createScene() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(50));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("border-pane");
        root.getStyleClass().add("login-scene");

        // Titre
        Label titleLabel = new Label("Application de Réservation");
        titleLabel.getStyleClass().add("title-label");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        titleLabel.setStyle("-fx-text-fill: #333333;");

        Label subtitleLabel = new Label("Restaurant Universitaire");
        subtitleLabel.getStyleClass().add("subtitle-label");

        // Formulaire de connexion
        VBox formBox = new VBox(15);
        formBox.getStyleClass().add("login-card");
        formBox.setPadding(new Insets(30));
        formBox.setMaxWidth(400);

        Label emailLabel = new Label("Email:");
        emailLabel.getStyleClass().add("label");
        TextField emailField = new TextField(initialEmail);
        emailField.setPromptText("exemple@ihec.ucar.tn");
        emailField.getStyleClass().add("text-field");

        Label passwordLabel = new Label("Mot de passe:");
        passwordLabel.getStyleClass().add("label");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Entrez votre mot de passe");
        passwordField.getStyleClass().add("password-field");

        // Boutons de connexion et d'effacement
        HBox loginButtonBox = new HBox(10);
        loginButtonBox.setAlignment(Pos.CENTER);

        Button loginButton = new Button("Connexion");
        loginButton.getStyleClass().addAll("button", "button-primary");
        loginButton.setOnAction(e -> {
            String email = emailField.getText().trim();
            String password = passwordField.getText();

            if (!isValidEmail(email)) {
                showAlert(AlertType.ERROR, "Erreur de format", "Veuillez entrer une adresse email valide.");
                return;
            }

            if (email.isEmpty() || password.isEmpty()) {
                showAlert(AlertType.WARNING, "Champs manquants", "Veuillez remplir tous les champs.");
            } else {
                loginCallback.accept(email, password);
            }
        });

        Button clearButton = new Button("Effacer");
        clearButton.getStyleClass().addAll("button", "button-danger");
        clearButton.setOnAction(e -> {
            emailField.clear();
            passwordField.clear();
        });

        loginButtonBox.getChildren().addAll(loginButton, clearButton);
        
        // Bouton d'inscription
        Button signupButton = new Button("Pas de compte ? S'inscrire");
        signupButton.getStyleClass().addAll("button", "button-secondary");
        signupButton.setOnAction(e -> signupCallback.accept(""));

        // Informations d'aide
        Label helpLabel = new Label("Identifiants de test:");
        helpLabel.getStyleClass().add("label");
        helpLabel.setStyle("-fx-font-weight: bold;");

        Label chefLabel = new Label("Chef: chef.principal@ihec.ucar.tn / 1234");
        chefLabel.setStyle("-fx-font-size: 10pt;");

        Label etudiantLabel = new Label("Étudiant: nom.prenom.2024@ihec.ucar.tn / 2024");
        etudiantLabel.setStyle("-fx-font-size: 10pt;");

        formBox.getChildren().addAll(
                emailLabel, emailField,
                passwordLabel, passwordField,
                loginButtonBox,
                new Separator(),
                signupButton,
                new Separator(),
                helpLabel, chefLabel, etudiantLabel
        );

        root.getChildren().addAll(titleLabel, subtitleLabel, formBox);

        // Validation en temps réel et désactivation du bouton
        Runnable updateButtonState = () -> {
            boolean isEmailValid = isValidEmail(emailField.getText().trim());
            boolean isPasswordPresent = !passwordField.getText().isEmpty();
            loginButton.setDisable(!(isEmailValid && isPasswordPresent));

            if (!emailField.getText().isEmpty() && !isEmailValid) {
                emailField.getStyleClass().add("invalid-field");
            } else {
                emailField.getStyleClass().remove("invalid-field");
            }
        };

        emailField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> updateButtonState.run());
        updateButtonState.run(); // Initial check

        return new Scene(root, 900, 700);
    }

    private boolean isValidEmail(String email) {
        // Regex spécifique pour le format nom.prenom.annee@ihec.ucar.tn ou le chef
        if (email.equalsIgnoreCase("chef.principal@ihec.ucar.tn")) return true;
        return email.matches("^[a-zA-Z]+\\.[a-zA-Z]+\\.\\d{4}@ihec\\.ucar\\.tn$");
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public Scene getScene() {
        return scene;
    }
}
