package app;

import models.ChefPrincipal;
import models.Etudiant;
import models.MenuJour;
import models.Plat;
import models.Utilisateur;
import services.MenuService;
import services.ReservationService;
import services.UserService;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main_Console {
    private static final Scanner scanner = new Scanner(System.in);
    private static final UserService userService = new UserService();
    private static final MenuService menuService = new MenuService();
    private static final ReservationService reservationService = new ReservationService(menuService);
    private static Utilisateur utilisateurConnecte = null;

    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("  Application de Réservation du Restaurant U");
        System.out.println("==================================================");

        authentification();

        if (utilisateurConnecte != null) {
            if (utilisateurConnecte instanceof ChefPrincipal) {
                menuChef();
            } else if (utilisateurConnecte instanceof Etudiant) {
                menuEtudiant();
            }
        }

        System.out.println("Fermeture de l'application. Au revoir !");
    }

    private static void authentification() {
        while (utilisateurConnecte == null) {
            System.out.println("\n--- Authentification ---");
            System.out.print("Email: ");
            System.out.flush();
            String email = scanner.nextLine();
            System.out.print("Mot de passe: ");
            System.out.flush();
            String motDePasse = scanner.nextLine();

            Optional<Utilisateur> user = userService.authentifier(email, motDePasse);

            if (user.isPresent()) {
                utilisateurConnecte = user.get();
                System.out.println("\nConnexion réussie. Bienvenue, " + utilisateurConnecte.getPrenom() + " !");
            } else {
                System.out.println("Erreur d'authentification. Veuillez vérifier votre email et mot de passe.");
            }
        }
    }

    // ==================================================
    // Menu Chef Principal
    // ==================================================

    private static void menuChef() {
        boolean quitter = false;
        while (!quitter) {
            System.out.println("\n--- Menu Chef Principal ---");
            System.out.println("1. Gérer le menu de la semaine");
            System.out.println("2. Consulter les réservations du jour");
            System.out.println("3. Valider la prise de repas");
            System.out.println("4. Déconnexion");
            System.out.print("Votre choix: ");

            String choix = scanner.nextLine();
            try {
                switch (choix) {
                    case "1":
                        gererMenuSemaine();
                        break;
                    case "2":
                        consulterReservationsDuJour();
                        break;
                    case "3":
                        validerPriseRepas();
                        break;
                    case "4":
                        quitter = true;
                        break;
                    default:
                        System.out.println("Choix invalide.");
                }
            } catch (Exception e) {
                System.err.println("Erreur: " + e.getMessage());
            }
        }
    }

    private static void gererMenuSemaine() {
        if (menuService.menuExiste()) {
            System.out.println("\nLe menu de la semaine a déjà été saisi et ne peut pas être modifié.");
            afficherMenu(menuService.getMenuDeLaSemaine());
            return;
        }

        if (!menuService.estPeriodeSaisieMenu()) {
            System.out.println("\nLa saisie du menu n'est autorisée que le samedi et le dimanche.");
            return;
        }

        System.out.println("\n--- Saisie du Menu de la Semaine (Lundi au Vendredi) ---");
        List<MenuJour> nouveauMenu = new ArrayList<>();
        List<DayOfWeek> joursDeSemaine = Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY);

        for (DayOfWeek jour : joursDeSemaine) {
            System.out.println("\nSaisie du menu pour le " + jour + ":");
            MenuJour menuJour = new MenuJour(jour);
            boolean saisieTerminee = false;
            while (!saisieTerminee) {
                System.out.print("Nom du plat (ou 'fin' pour terminer la saisie des plats pour ce jour): ");
                String nomPlat = scanner.nextLine();
                if (nomPlat.equalsIgnoreCase("fin")) {
                    if (menuJour.getPlats().isEmpty()) {
                        System.out.println("Veuillez saisir au moins un plat pour ce jour.");
                        continue;
                    }
                    saisieTerminee = true;
                } else {
                    System.out.print("Liste des aliments (séparés par des virgules): ");
                    String aliments = scanner.nextLine();
                    menuJour.ajouterPlat(new Plat(nomPlat, aliments));
                    System.out.println("Plat ajouté.");
                }
            }
            nouveauMenu.add(menuJour);
        }

        try {
            menuService.creerMenuDeLaSemaine(nouveauMenu);
            System.out.println("\n✅ Menu de la semaine créé et sauvegardé avec succès !");
        } catch (Exception e) {
            System.err.println("Erreur lors de la création du menu: " + e.getMessage());
        }
    }

    private static void consulterReservationsDuJour() {
        DayOfWeek aujourdHui = LocalDate.now().getDayOfWeek();
        if (aujourdHui == DayOfWeek.SATURDAY || aujourdHui == DayOfWeek.SUNDAY) {
            System.out.println("Le restaurant est fermé le week-end.");
            return;
        }

        System.out.println("\n--- Réservations pour le " + aujourdHui + " ---");
        List<models.Reservation> reservationsDuJour = reservationService.getReservationsParJour(aujourdHui);

        if (reservationsDuJour.isEmpty()) {
            System.out.println("Aucune réservation pour aujourd'hui.");
            return;
        }

        System.out.printf("%-5s | %-20s | %-20s | %-10s\n", "N°", "Nom", "Prénom", "Pris");
        System.out.println("----------------------------------------------------------");

        for (int i = 0; i < reservationsDuJour.size(); i++) {
            models.Reservation r = reservationsDuJour.get(i);
            Optional<Etudiant> etudiant = userService.getEtudiantParEmail(r.getEmailEtudiant());
            if (etudiant.isPresent()) {
                System.out.printf("%-5d | %-20s | %-20s | %-10s\n",
                        i + 1,
                        etudiant.get().getNom(),
                        etudiant.get().getPrenom(),
                        r.isRepasPris() ? "OUI" : "NON");
            }
        }
    }

    private static void validerPriseRepas() {
        DayOfWeek aujourdHui = LocalDate.now().getDayOfWeek();
        if (aujourdHui == DayOfWeek.SATURDAY || aujourdHui == DayOfWeek.SUNDAY) {
            System.out.println("Le restaurant est fermé le week-end.");
            return;
        }

        System.out.println("\n--- Validation de la Prise de Repas pour le " + aujourdHui + " ---");
        List<models.Reservation> reservationsDuJour = reservationService.getReservationsParJour(aujourdHui).stream()
                .filter(r -> !r.isRepasPris())
                .collect(Collectors.toList());

        if (reservationsDuJour.isEmpty()) {
            System.out.println("Toutes les réservations ont déjà été validées ou il n'y a pas de réservations.");
            return;
        }

        System.out.printf("%-5s | %-20s | %-20s | %-30s\n", "N°", "Nom", "Prénom", "Email");
        System.out.println("---------------------------------------------------------------------------------");

        for (int i = 0; i < reservationsDuJour.size(); i++) {
            models.Reservation r = reservationsDuJour.get(i);
            Optional<Etudiant> etudiant = userService.getEtudiantParEmail(r.getEmailEtudiant());
            if (etudiant.isPresent()) {
                System.out.printf("%-5d | %-20s | %-20s | %-30s\n",
                        i + 1,
                        etudiant.get().getNom(),
                        etudiant.get().getPrenom(),
                        r.getEmailEtudiant());
            }
        }

        System.out.print("\nEntrez le numéro de l'étudiant à valider (ou 'q' pour annuler): ");
        String choix = scanner.nextLine();

        if (choix.equalsIgnoreCase("q")) {
            return;
        }

        try {
            int index = Integer.parseInt(choix) - 1;
            if (index >= 0 && index < reservationsDuJour.size()) {
                models.Reservation r = reservationsDuJour.get(index);
                reservationService.validerRepasPris(r.getEmailEtudiant(), aujourdHui);
                System.out.println("✅ Repas de " + userService.getEtudiantParEmail(r.getEmailEtudiant()).get().getPrenom() + " validé.");
            } else {
                System.out.println("Numéro invalide.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Saisie invalide.");
        } catch (Exception e) {
            System.err.println("Erreur: " + e.getMessage());
        }
    }

    // ==================================================
    // Menu Étudiant
    // ==================================================

    private static void menuEtudiant() {
        boolean quitter = false;
        while (!quitter) {
            System.out.println("\n--- Menu Étudiant ---");
            System.out.println("1. Afficher le menu de la semaine");
            System.out.println("2. Réserver un repas");
            System.out.println("3. Noter un repas pris");
            System.out.println("4. Afficher mes réservations");
            System.out.println("5. Déconnexion");
            System.out.print("Votre choix: ");

            String choix = scanner.nextLine();
            try {
                switch (choix) {
                    case "1":
                        afficherMenu(menuService.getMenuDeLaSemaine());
                        break;
                    case "2":
                        reserverRepas();
                        break;
                    case "3":
                        noterRepas();
                        break;
                    case "4":
                        afficherMesReservations();
                        break;
                    case "5":
                        quitter = true;
                        break;
                    default:
                        System.out.println("Choix invalide.");
                }
            } catch (Exception e) {
                System.err.println("Erreur: " + e.getMessage());
            }
        }
    }

    private static void afficherMenu(List<MenuJour> menu) {
        if (menu.isEmpty()) {
            System.out.println("\nLe menu de la semaine n'a pas encore été saisi par le chef.");
            return;
        }

        System.out.println("\n--- Menu de la Semaine ---");
        for (MenuJour mj : menu) {
            System.out.println("• " + mj.getJour() + ":");
            for (Plat p : mj.getPlats()) {
                System.out.println("    - " + p.getNom() + " (" + p.getAliments() + ")");
            }
        }
    }

    private static void reserverRepas() {
        if (!menuService.menuExiste()) {
            System.out.println("Impossible de réserver, le menu de la semaine n'est pas encore disponible.");
            return;
        }

        Etudiant etudiant = (Etudiant) utilisateurConnecte;
        List<DayOfWeek> joursDisponibles = menuService.getMenuDeLaSemaine().stream()
                .map(MenuJour::getJour)
                .collect(Collectors.toList());

        System.out.println("\n--- Réservation de Repas ---");
        System.out.println("Jours disponibles à la réservation:");

        for (int i = 0; i < joursDisponibles.size(); i++) {
            DayOfWeek jour = joursDisponibles.get(i);
            Optional<models.Reservation> reservationExistante = reservationService.getReservation(etudiant.getEmail(), jour);
            String statut = reservationExistante.isPresent() ? " (Déjà réservé)" : "";
            System.out.println((i + 1) + ". " + jour + statut);
        }

        System.out.print("Entrez le numéro du jour à réserver (ou 'q' pour annuler): ");
        String choix = scanner.nextLine();

        if (choix.equalsIgnoreCase("q")) {
            return;
        }

        try {
            int index = Integer.parseInt(choix) - 1;
            if (index >= 0 && index < joursDisponibles.size()) {
                DayOfWeek jourChoisi = joursDisponibles.get(index);
                reservationService.reserverRepas(etudiant, jourChoisi);
                System.out.println("✅ Repas pour le " + jourChoisi + " réservé avec succès !");
            } else {
                System.out.println("Numéro invalide.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Saisie invalide.");
        } catch (Exception e) {
            System.err.println("Erreur: " + e.getMessage());
        }
    }

    private static void noterRepas() {
        Etudiant etudiant = (Etudiant) utilisateurConnecte;
        List<models.Reservation> reservationsPrises = reservationService.getReservationsParEtudiant(etudiant.getEmail()).stream()
                .filter(models.Reservation::isRepasPris)
                .filter(r -> r.getNote() == 0) // Seulement ceux qui n'ont pas encore été notés
                .collect(Collectors.toList());

        if (reservationsPrises.isEmpty()) {
            System.out.println("\nAucun repas pris n'est en attente de notation.");
            return;
        }

        System.out.println("\n--- Notation des Repas Pris ---");
        System.out.printf("%-5s | %-15s | %-15s\n", "N°", "Jour", "Date Réservation");
        System.out.println("-----------------------------------------");

        for (int i = 0; i < reservationsPrises.size(); i++) {
            models.Reservation r = reservationsPrises.get(i);
            System.out.printf("%-5d | %-15s | %-15s\n",
                    i + 1,
                    r.getJourReserve(),
                    r.getDateReservation());
        }

        System.out.print("\nEntrez le numéro du repas à noter (ou 'q' pour annuler): ");
        String choix = scanner.nextLine();

        if (choix.equalsIgnoreCase("q")) {
            return;
        }

        try {
            int index = Integer.parseInt(choix) - 1;
            if (index >= 0 && index < reservationsPrises.size()) {
                models.Reservation r = reservationsPrises.get(index);
                System.out.print("Entrez votre note (1 à 5): ");
                int note = Integer.parseInt(scanner.nextLine());

                reservationService.noterRepas(etudiant.getEmail(), r.getJourReserve(), note);
                System.out.println("✅ Repas du " + r.getJourReserve() + " noté " + note + "/5 avec succès !");
            } else {
                System.out.println("Numéro invalide.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Saisie invalide (la note doit être un nombre).");
        } catch (Exception e) {
            System.err.println("Erreur: " + e.getMessage());
        }
    }

    private static void afficherMesReservations() {
        Etudiant etudiant = (Etudiant) utilisateurConnecte;
        List<models.Reservation> mesReservations = reservationService.getReservationsParEtudiant(etudiant.getEmail());

        if (mesReservations.isEmpty()) {
            System.out.println("\nVous n'avez effectué aucune réservation.");
            return;
        }

        System.out.println("\n--- Mes Réservations ---");
        System.out.printf("%-15s | %-15s | %-10s | %-5s\n", "Jour", "Date Réservation", "Pris", "Note");
        System.out.println("-------------------------------------------------");

        for (models.Reservation r : mesReservations) {
            String noteStr = r.getNote() > 0 ? String.valueOf(r.getNote()) : "-";
            System.out.printf("%-15s | %-15s | %-10s | %-5s\n",
                    r.getJourReserve(),
                    r.getDateReservation(),
                    r.isRepasPris() ? "OUI" : "NON",
                    noteStr);
        }
    }
}
