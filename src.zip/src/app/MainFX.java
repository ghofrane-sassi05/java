package app;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.ChefPrincipal;
import models.Etudiant;
import models.Utilisateur;
import services.MenuService;
import services.ReservationService;
import services.UserService;
import ui.LoginScene;
import ui.ChefScene;
import ui.EtudiantScene;
import ui.SignupScene; // Import de la nouvelle scène

import java.util.Optional;

public class MainFX extends Application {
    private static final String CSS_PATH = "/ressources/style.css";
    private Stage primaryStage;
    private UserService userService;
    private MenuService menuService;
    private ReservationService reservationService;
    private Utilisateur utilisateurConnecte;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.userService = new UserService();
        this.menuService = new MenuService();
        this.reservationService = new ReservationService(menuService);

        primaryStage.setTitle("Application de Réservation du Restaurant Universitaire");
        primaryStage.setWidth(900);
        primaryStage.setHeight(700);

        showLoginScene();
        primaryStage.show();
    }

    private void loadCss(Scene scene) {
        String css = getClass().getResource(CSS_PATH).toExternalForm();
        scene.getStylesheets().add(css);
    }

    private void showLoginScene() {
        showLoginScene("");
    }
    
    private void showLoginScene(String initialEmail) {
        LoginScene loginScene = new LoginScene(this::handleLogin, this::showSignupScene, initialEmail);
        primaryStage.setScene(loginScene.getScene());
        loadCss(primaryStage.getScene());
    }
    
    private void showSignupScene(String initialEmail) {
        SignupScene signupScene = new SignupScene(this::showLoginScene, userService);
        primaryStage.setScene(signupScene.getScene());
        loadCss(primaryStage.getScene());
    }

    private void handleLogin(String email, String password) {
        // Authentification directe via le service
        Optional<Utilisateur> user = userService.authentifier(email, password);

        if (user.isPresent()) {
            utilisateurConnecte = user.get();
            if (utilisateurConnecte instanceof ChefPrincipal) {
                showChefScene();
            } else if (utilisateurConnecte instanceof Etudiant) {
                showEtudiantScene();
            }
        } else {
            // Vérifier si l'email existe pour donner un message plus précis
            if (userService.getUtilisateurParEmail(email).isEmpty()) {
                showAlert("Erreur d'authentification", "Email incorrect ou utilisateur non inscrit.");
            } else {
                showAlert("Erreur d'authentification", "Mot de passe incorrect.");
            }
        }
    }

    private void showChefScene() {
        ChefScene chefScene = new ChefScene(
                (ChefPrincipal) utilisateurConnecte,
                menuService,
                reservationService,
                userService,
                this::showLoginScene
        );
        primaryStage.setScene(chefScene.getScene());
        loadCss(primaryStage.getScene());
    }

    private void showEtudiantScene() {
        EtudiantScene etudiantScene = new EtudiantScene(
                (Etudiant) utilisateurConnecte,
                menuService,
                reservationService,
                this::showLoginScene
        );
        primaryStage.setScene(etudiantScene.getScene());
        loadCss(primaryStage.getScene());
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
