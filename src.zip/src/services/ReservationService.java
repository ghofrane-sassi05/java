package services;

import models.Etudiant;
import models.Reservation;
import models.Plat;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ReservationService {
    private final BaseFileService<Reservation> reservationFileService;
    private List<Reservation> reservations;
    private final MenuService menuService; // Ajout pour accéder aux plats

    public ReservationService(MenuService menuService) {
        this.reservationFileService = new BaseFileService<>("reservations.csv", Reservation::fromCSV, Reservation::toCSV);
        this.reservations = new ArrayList<>();
        this.menuService = menuService;
        chargerReservations();
    }

    private void chargerReservations() {
        try {
            this.reservations = reservationFileService.lireFichier();
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement des réservations: " + e.getMessage());
        }
    }

    private void sauvegarderReservations() {
        try {
            reservationFileService.ecrireFichier(reservations);
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde des réservations: " + e.getMessage());
        }
    }

    public List<Reservation> getReservationsParEtudiant(String emailEtudiant) {
        return reservations.stream()
                .filter(r -> r.getEmailEtudiant().equalsIgnoreCase(emailEtudiant))
                .collect(Collectors.toList());
    }

    public List<Reservation> getReservationsParJour(DayOfWeek jour) {
        return reservations.stream()
                .filter(r -> r.getJourReserve() == jour)
                .collect(Collectors.toList());
    }

    public Optional<Reservation> getReservation(String emailEtudiant, DayOfWeek jour) {
        return reservations.stream()
                .filter(r -> r.getEmailEtudiant().equalsIgnoreCase(emailEtudiant) && r.getJourReserve() == jour)
                .findFirst();
    }

    public void reserverRepas(Etudiant etudiant, DayOfWeek jour) {
        // Par défaut, on prend le premier plat du menu du jour si non spécifié (pour la console)
        Optional<models.MenuJour> mj = menuService.getMenuDuJour(jour);
        if (mj.isPresent() && !mj.get().getPlats().isEmpty()) {
            reserverRepas(etudiant, jour, mj.get().getPlats().get(0).getId());
        } else {
            throw new IllegalStateException("Aucun plat disponible pour ce jour.");
        }
    }

    public void reserverRepas(Etudiant etudiant, DayOfWeek jour, String platId) {
        // 1. Vérification de la date limite
        if (!estDansLesTemps(jour)) {
            throw new IllegalStateException("La date limite de réservation pour le " + jour + " est dépassée (midi du jour J-1).");
        }

        // 2. Vérification si déjà réservé
        if (getReservation(etudiant.getEmail(), jour).isPresent()) {
            throw new IllegalStateException("Vous avez déjà réservé le repas pour le " + jour + ".");
        }

        // 3. Vérification si le plat existe pour ce jour (facultatif mais bonne pratique)
        Optional<Plat> platChoisi = menuService.getPlatParId(platId);
        if (platChoisi.isEmpty()) {
            throw new IllegalArgumentException("Le plat sélectionné n'existe pas.");
        }
        
        // 4. Création et sauvegarde de la réservation
        Reservation nouvelleReservation = new Reservation(etudiant.getEmail(), jour, LocalDate.now(), platId);
        reservations.add(nouvelleReservation);
        sauvegarderReservations();
    }

    public boolean reservationExiste(String email, DayOfWeek jour) {
        return getReservation(email, jour).isPresent();
    }

    public void reserver(String email, DayOfWeek jour, String platId) {
        // Cette méthode est utilisée par l'UI qui n'a que l'email
        // On pourrait récupérer l'objet Etudiant via UserService si nécessaire, 
        // mais reserverRepas n'utilise que l'email de l'étudiant pour la création.
        // Pour rester cohérent avec la signature attendue par l'UI :
        if (reservationExiste(email, jour)) {
            throw new IllegalStateException("Réservation déjà existante.");
        }
        
        Reservation nouvelleReservation = new Reservation(email, jour, LocalDate.now(), platId);
        reservations.add(nouvelleReservation);
        sauvegarderReservations();
    }

    private boolean estDansLesTemps(DayOfWeek jour) {
        // TEMPORAIRE: Permet la réservation à tout moment pour les tests
        return true;
        /*
        // Le jour J est le jour de la semaine pour lequel on réserve
        // La date limite est midi du jour J-1

        // 1. Trouver la date du jour J de cette semaine
        LocalDate aujourdHui = LocalDate.now();
        LocalDate dateJourJ = aujourdHui.with(java.time.temporal.TemporalAdjusters.nextOrSame(jour));

        // 2. Calculer la date limite (midi du jour J-1)
        LocalDate dateJourJMoins1 = dateJourJ.minusDays(1);
        LocalDateTime dateLimite = LocalDateTime.of(dateJourJMoins1, LocalTime.of(12, 0));

        // 3. Comparer avec maintenant
        return LocalDateTime.now().isBefore(dateLimite);
        */
    }

    public void validerRepasPris(String emailEtudiant, DayOfWeek jour) {
        Optional<Reservation> optReservation = getReservation(emailEtudiant, jour);
        if (optReservation.isPresent()) {
            Reservation reservation = optReservation.get();
            if (reservation.getJourReserve() != LocalDate.now().getDayOfWeek()) {
                throw new IllegalStateException("Impossible de valider la prise de repas pour un autre jour que le jour actuel.");
            }
            reservation.setRepasPris(true);
            sauvegarderReservations();
        } else {
            throw new IllegalArgumentException("Aucune réservation trouvée pour cet étudiant et ce jour.");
        }
    }

    public void noterRepas(String emailEtudiant, DayOfWeek jour, String noteStr) {
        try {
            int note = Integer.parseInt(noteStr);
            noterRepas(emailEtudiant, jour, note);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("La note doit être un nombre valide.");
        }
    }

    public void noterRepas(String emailEtudiant, DayOfWeek jour, int note) {
        Optional<Reservation> optReservation = getReservation(emailEtudiant, jour);
        if (optReservation.isPresent()) {
            Reservation reservation = optReservation.get();
            if (!reservation.isRepasPris()) {
                throw new IllegalStateException("Vous ne pouvez noter que les repas que vous avez réservés ET pris.");
            }
            if (note < 1 || note > 5) {
                throw new IllegalArgumentException("La note doit être comprise entre 1 et 5.");
            }
            reservation.setNote(note);
            sauvegarderReservations();
        } else {
            throw new IllegalArgumentException("Aucune réservation trouvée pour cet étudiant et ce jour.");
        }
    }

    /**
     * Retourne les statistiques de réservation pour un jour donné.
     * @param jour Le jour de la semaine.
     * @return Une Map où la clé est le nom du plat et la valeur est le nombre de réservations.
     */
    public Map<String, Long> getStatistiquesReservations(DayOfWeek jour) {
        // 1. Filtrer les réservations pour le jour donné
        List<Reservation> reservationsDuJour = getReservationsParJour(jour);

        // 2. Grouper par platId et compter
        Map<String, Long> countParPlatId = reservationsDuJour.stream()
                .collect(Collectors.groupingBy(Reservation::getPlatId, Collectors.counting()));

        // 3. Remplacer les platId par les noms de plats
        return countParPlatId.entrySet().stream()
                .collect(Collectors.toMap(
                        entry -> menuService.getPlatParId(entry.getKey())
                                .map(Plat::getNom)
                                .orElse("Plat Inconnu"),
                        Map.Entry::getValue
                ));
    }
}
