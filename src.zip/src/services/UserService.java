package services;

import models.ChefPrincipal;
import models.Etudiant;
import models.Utilisateur;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserService {
    private final BaseFileService<Etudiant> etudiantFileService;
    private List<Etudiant> etudiants;
    private final ChefPrincipal chefPrincipal;

    public UserService() {
        // Initialisation du service de fichier pour les étudiants
        this.etudiantFileService = new BaseFileService<>("users.csv", Etudiant::fromCSV, Etudiant::toCSV);
        this.chefPrincipal = new ChefPrincipal();
        this.etudiants = new ArrayList<>();
        chargerEtudiants();
    }

    private void chargerEtudiants() {
        try {
            this.etudiants = etudiantFileService.lireFichier();
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement des étudiants: " + e.getMessage());
        }
    }

    private void sauvegarderEtudiants() {
        try {
            etudiantFileService.ecrireFichier(etudiants);
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde des étudiants: " + e.getMessage());
        }
    }

    public Optional<Utilisateur> authentifier(String email, String motDePasse) {
        // 1. Vérification du Chef Principal
        if (chefPrincipal.getEmail().equalsIgnoreCase(email) && chefPrincipal.getMotDePasse().equals(motDePasse)) {
            return Optional.of(chefPrincipal);
        }

        // 2. Vérification des Étudiants
        Optional<Etudiant> etudiantExistant = etudiants.stream()
                .filter(e -> e.getEmail().equalsIgnoreCase(email))
                .findFirst();

        if (etudiantExistant.isPresent()) {
            if (etudiantExistant.get().getMotDePasse().trim().equals(motDePasse.trim())) {
                return Optional.of(etudiantExistant.get());
            }
        }
        // La création automatique est déplacée vers creerCompteEtudiant pour le flux d'inscription


        return Optional.empty();
    }

    public List<Etudiant> getTousLesEtudiants() {
        return etudiants;
    }

    public Optional<Etudiant> getEtudiantParEmail(String email) {
        return etudiants.stream()
                .filter(e -> e.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    public Optional<Utilisateur> getUtilisateurParEmail(String email) {
        // 1. Vérification du Chef Principal
        if (chefPrincipal.getEmail().equalsIgnoreCase(email)) {
            return Optional.of(chefPrincipal);
        }

        // 2. Vérification des Étudiants
        Optional<Etudiant> etudiantExistant = etudiants.stream()
                .filter(e -> e.getEmail().equalsIgnoreCase(email))
                .findFirst();

        if (etudiantExistant.isPresent()) {
            return Optional.of(etudiantExistant.get());
        }

        return Optional.empty();
    }

    /**
     * Crée un nouveau compte étudiant.
     * @param email L'email de l'étudiant.
     * @param motDePasse Le mot de passe.
     * @return true si le compte a été créé, false sinon (email déjà existant ou format invalide).
     */
    public boolean creerCompteEtudiant(String email, String motDePasse) {
        // Vérification du format de l'email
        if (!email.matches("^[a-zA-Z]+\\.[a-zA-Z]+\\.\\d{4}@ihec\\.ucar\\.tn$")) {
            return false;
        }

        // Vérification si l'étudiant existe déjà
        if (getEtudiantParEmail(email).isPresent()) {
            return false;
        }

        // Création et sauvegarde du nouvel étudiant
        Etudiant nouvelEtudiant = new Etudiant(email, motDePasse);
        etudiants.add(nouvelEtudiant);
        sauvegarderEtudiants();
        return true;
    }
}
