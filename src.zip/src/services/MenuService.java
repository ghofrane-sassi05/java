package services;

import models.MenuJour;
import models.Plat;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MenuService {
    private final BaseFileService<Plat> platFileService;
    private final BaseFileService<String> menuFileService; // Stocke les lignes CSV du menu
    private List<Plat> tousLesPlats;
    private List<MenuJour> menuDeLaSemaine;

    public MenuService() {
        this.platFileService = new BaseFileService<>("plats.csv", Plat::fromCSV, Plat::toCSV);
        this.menuFileService = new BaseFileService<>("menu.csv", s -> s, s -> s); // Simple String pour le menu
        this.tousLesPlats = new ArrayList<>();
        this.menuDeLaSemaine = new ArrayList<>();
        chargerDonnees();
    }

    private void chargerDonnees() {
        try {
            this.tousLesPlats = platFileService.lireFichier();
            List<String> menuLignes = menuFileService.lireFichier();
            this.menuDeLaSemaine = menuLignes.stream()
                    .map(ligne -> MenuJour.fromCSV(ligne, tousLesPlats))
                    .filter(m -> m != null)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement des données de menu: " + e.getMessage());
        }
    }

    private void sauvegarderDonnees() {
        try {
            // Sauvegarde des plats (pour s'assurer que les nouveaux plats sont enregistrés)
            platFileService.ecrireFichier(tousLesPlats);

            // Sauvegarde du menu
            List<String> menuLignes = menuDeLaSemaine.stream()
                    .map(menuJour -> menuJour.toCSV(tousLesPlats))
                    .collect(Collectors.toList());
            menuFileService.ecrireFichier(menuLignes);
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde des données de menu: " + e.getMessage());
        }
    }

    public List<MenuJour> getMenuDeLaSemaine() {
        return menuDeLaSemaine;
    }

    public Optional<MenuJour> getMenuDuJour(DayOfWeek jour) {
        return menuDeLaSemaine.stream()
                .filter(m -> m.getJour() == jour)
                .findFirst();
    }

    public Optional<MenuJour> getMenuJour(DayOfWeek jour) {
        return getMenuDuJour(jour);
    }
    
    public Optional<Plat> getPlatParId(String id) {
        return tousLesPlats.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    public boolean estPeriodeSaisieMenu() {
        // DayOfWeek aujourdHui = LocalDate.now().getDayOfWeek();
        // return aujourdHui == DayOfWeek.SATURDAY || aujourdHui == DayOfWeek.SUNDAY;
        return true; // TEMPORAIRE: Permet la saisie du menu à tout moment pour les tests
    }

    public boolean menuExiste() {
        return !menuDeLaSemaine.isEmpty();
    }

    public void creerMenuDeLaSemaine(List<MenuJour> nouveauMenu) {
        // 1. Vérification des règles de saisie
        if (!estPeriodeSaisieMenu()) {
            throw new IllegalStateException("La saisie du menu n'est autorisée que le samedi et le dimanche.");
        }
        if (menuExiste()) {
            throw new IllegalStateException("Le menu de la semaine a déjà été saisi et ne peut pas être modifié.");
        }
        if (nouveauMenu.size() != 5) {
            throw new IllegalArgumentException("Le menu doit contenir exactement 5 jours (du lundi au vendredi).");
        }
        if (!nouveauMenu.stream().map(MenuJour::getJour).collect(Collectors.toList()).containsAll(Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY))) {
            throw new IllegalArgumentException("Le menu doit couvrir du lundi au vendredi.");
        }

        // 2. Mise à jour des plats et du menu
        this.menuDeLaSemaine.clear();
        for (MenuJour mj : nouveauMenu) {
            for (Plat p : mj.getPlats()) {
                // On ajoute le plat à la liste globale s'il n'existe pas déjà (basé sur le nom pour simplifier)
                if (tousLesPlats.stream().noneMatch(tp -> tp.getNom().equalsIgnoreCase(p.getNom()))) {
                    tousLesPlats.add(p);
                }
            }
            this.menuDeLaSemaine.add(mj);
        }

        // 3. Sauvegarde
        sauvegarderDonnees();
    }
}
