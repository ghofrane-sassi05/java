package services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class BaseFileService<T> implements FileService<T> {
    protected final String cheminFichier;
    protected final Function<String, T> fromCSV;
    protected final Function<T, String> toCSV;

    public BaseFileService(String nomFichier, Function<String, T> fromCSV, Function<T, String> toCSV) {
        this.cheminFichier = "data/" + nomFichier;
        this.fromCSV = fromCSV;
        this.toCSV = toCSV;
    }

    @Override
    public List<T> lireFichier() throws IOException {
        List<T> donnees = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(cheminFichier))) {
            String ligne;
            while ((ligne = br.readLine()) != null) {
                T objet = fromCSV.apply(ligne);
                if (objet != null) {
                    donnees.add(objet);
                }
            }
        } catch (java.io.FileNotFoundException e) {
            // Le fichier n'existe pas encore, ce n'est pas une erreur critique
            // On retourne une liste vide
        }
        return donnees;
    }

    @Override
    public void ecrireFichier(List<T> donnees) throws IOException {
        java.io.File file = new java.io.File(cheminFichier);
        java.io.File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            for (T objet : donnees) {
                bw.write(toCSV.apply(objet));
                bw.newLine();
            }
        }
    }
}
