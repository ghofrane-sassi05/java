package services;

import java.io.IOException;
import java.util.List;

public interface FileService<T> {
    List<T> lireFichier() throws IOException;
    void ecrireFichier(List<T> donnees) throws IOException;
}
