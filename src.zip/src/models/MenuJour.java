package models;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MenuJour {
    private DayOfWeek jour;
    private List<Plat> plats;

    public MenuJour(DayOfWeek jour) {
        this.jour = jour;
        this.plats = new ArrayList<>();
    }

    // Getters
    public DayOfWeek getJour() {
        return jour;
    }

    public List<Plat> getPlats() {
        return plats;
    }

    // Méthodes
    public void ajouterPlat(Plat plat) {
        this.plats.add(plat);
    }

    @Override
    public String toString() {
        String platsStr = plats.stream()
                               .map(Plat::toString)
                               .collect(Collectors.joining(", "));
        return jour.toString() + ": " + platsStr;
    }

    // Méthode pour obtenir la représentation CSV (pour menu.csv)
    // Format: JOUR;ID_PLAT1,ID_PLAT2,...
    public String toCSV(List<Plat> tousLesPlats) {
        String platIds = plats.stream()
                              .map(Plat::getId)
                              .collect(Collectors.joining(","));
        return String.format("%s;%s", jour.toString(), platIds);
    }

    // Méthode statique pour créer un MenuJour à partir d'une ligne CSV
    public static MenuJour fromCSV(String csvLine, List<Plat> tousLesPlats) {
        String[] parts = csvLine.split(";");
        if (parts.length == 2) {
            try {
                DayOfWeek jour = DayOfWeek.valueOf(parts[0]);
                MenuJour menuJour = new MenuJour(jour);
                String[] platIds = parts[1].split(",");
                for (String id : platIds) {
                    tousLesPlats.stream()
                                .filter(p -> p.getId().equals(id))
                                .findFirst()
                                .ifPresent(menuJour::ajouterPlat);
                }
                return menuJour;
            } catch (IllegalArgumentException e) {
                // Le jour n'est pas valide
                return null;
            }
        }
        return null;
    }
}
