package models;

public class ChefPrincipal extends Utilisateur {
    // Constantes pour le chef principal
    public static final String EMAIL_CHEF = "chef.principal@ihec.ucar.tn";
    public static final String MDP_CHEF = "1234";
    public static final String NOM_CHEF = "Principal";
    public static final String PRENOM_CHEF = "Chef";

    public ChefPrincipal() {
        super(EMAIL_CHEF, MDP_CHEF, NOM_CHEF, PRENOM_CHEF);
    }

    @Override
    public String getType() {
        return "Chef";
    }
}
