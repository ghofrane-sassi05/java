package models;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Reservation {
    private String emailEtudiant;
    private DayOfWeek jourReserve;
    private LocalDate dateReservation; // Date à laquelle la réservation a été faite
    private boolean repasPris;
    private int note; // 0 si non noté, 1-5 si noté
    private String platId; // ID du plat réservé

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public Reservation(String emailEtudiant, DayOfWeek jourReserve, LocalDate dateReservation, String platId) {
        this.emailEtudiant = emailEtudiant;
        this.jourReserve = jourReserve;
        this.dateReservation = dateReservation;
        this.repasPris = false;
        this.note = 0;
        this.platId = platId;
    }

    // Constructeur pour la lecture depuis CSV
    public Reservation(String emailEtudiant, DayOfWeek jourReserve, LocalDate dateReservation, boolean repasPris, int note, String platId) {
        this.emailEtudiant = emailEtudiant;
        this.jourReserve = jourReserve;
        this.dateReservation = dateReservation;
        this.repasPris = repasPris;
        this.note = note;
        this.platId = platId;
    }

    // Getters
    public String getEmailEtudiant() {
        return emailEtudiant;
    }

    public DayOfWeek getJourReserve() {
        return jourReserve;
    }

    public DayOfWeek getJour() {
        return jourReserve;
    }

    public LocalDate getDateReservation() {
        return dateReservation;
    }

    public boolean isRepasPris() {
        return repasPris;
    }

    public int getNote() {
        return note;
    }

    public String getPlatId() {
        return platId;
    }

    // Setters
    public void setRepasPris(boolean repasPris) {
        this.repasPris = repasPris;
    }

    public void setNote(int note) {
        if (note >= 1 && note <= 5) {
            this.note = note;
        }
    }

    public void setPlatId(String platId) {
        this.platId = platId;
    }

    // Méthode pour obtenir la représentation CSV
    // Format: emailEtudiant,jourReserve,dateReservation,repasPris,note,platId
    public String toCSV() {
        return String.format("%s,%s,%s,%b,%d,%s",
                emailEtudiant,
                jourReserve.toString(),
                dateReservation.format(DATE_FORMATTER),
                repasPris,
                note,
                platId);
    }

    // Méthode statique pour créer une réservation à partir d'une ligne CSV
    public static Reservation fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length == 6) {
            try {
                String email = parts[0];
                DayOfWeek jour = DayOfWeek.valueOf(parts[1]);
                LocalDate date = LocalDate.parse(parts[2], DATE_FORMATTER);
                boolean pris = Boolean.parseBoolean(parts[3]);
                int note = Integer.parseInt(parts[4]);
                String platId = parts[5];
                return new Reservation(email, jour, date, pris, note, platId);
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
}
