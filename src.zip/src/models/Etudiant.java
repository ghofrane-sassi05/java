package models;

public class Etudiant extends Utilisateur {
    private int anneeInscription;

    public Etudiant(String email, String motDePasse, String nom, String prenom, int anneeInscription) {
        super(email, motDePasse, nom, prenom);
        this.anneeInscription = anneeInscription;
    }

    // Constructeur pour la création automatique à partir de l'email
    public Etudiant(String email, String motDePasse) {
        super(email, motDePasse, "", "");
        // Extraction automatique du nom, prénom et année
        String[] parts = email.split("@")[0].split("\\.");
        if (parts.length == 3) {
            super.setNom(parts[0].substring(0, 1).toUpperCase() + parts[0].substring(1).toLowerCase());
            super.setPrenom(parts[1].substring(0, 1).toUpperCase() + parts[1].substring(1).toLowerCase());
            try {
                this.anneeInscription = Integer.parseInt(parts[2]);
            } catch (NumberFormatException e) {
                this.anneeInscription = 0; // Valeur par défaut en cas d'erreur
            }
        }
    }

    public int getAnneeInscription() {
        return anneeInscription;
    }

    public void setAnneeInscription(int anneeInscription) {
        this.anneeInscription = anneeInscription;
    }

    @Override
    public String getType() {
        return "Etudiant";
    }

    // Méthode pour obtenir la représentation CSV
    public String toCSV() {
        return String.format("%s,%s,%s,%s,%d", getEmail(), getMotDePasse(), getNom(), getPrenom(), anneeInscription);
    }

    // Méthode statique pour créer un étudiant à partir d'une ligne CSV
    public static Etudiant fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length == 5) {
            return new Etudiant(parts[0], parts[1], parts[2], parts[3], Integer.parseInt(parts[4]));
        }
        return null;
    }
}
