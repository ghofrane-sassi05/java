package models;

import java.util.UUID;

public class Plat {
    private String id;
    private String nom;
    private String aliments; // Liste d'aliments séparés par une virgule

    public Plat(String nom, String aliments) {
        this.id = UUID.randomUUID().toString();
        this.nom = nom;
        this.aliments = aliments;
    }

    // Constructeur pour la lecture depuis CSV
    public Plat(String id, String nom, String aliments) {
        this.id = id;
        this.nom = nom;
        this.aliments = aliments;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getAliments() {
        return aliments;
    }

    // Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAliments(String aliments) {
        this.aliments = aliments;
    }

    @Override
    public String toString() {
        return nom + " (" + aliments + ")";
    }

    // Méthode pour obtenir la représentation CSV
    public String toCSV() {
        return String.format("%s,%s,%s", id, nom, aliments);
    }

    // Méthode statique pour créer un plat à partir d'une ligne CSV
    public static Plat fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length == 3) {
            return new Plat(parts[0], parts[1], parts[2]);
        }
        return null;
    }
}
