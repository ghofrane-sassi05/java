# Application de Réservation du Restaurant Universitaire (JavaFX)

Ce projet est une application de gestion des réservations de repas dans un restaurant universitaire. L'application a été mise à jour pour utiliser une interface graphique moderne basée sur **JavaFX**, remplaçant l'ancienne interface console.

## Architecture du Projet

Le projet est structuré en plusieurs packages :

*   `app`: Contient la classe principale `MainFX` pour l'exécution de l'application JavaFX, ainsi que l'ancienne classe `Main_Console` (renommée) pour référence.
*   `models`: Contient les classes de données (entités) du domaine (`Utilisateur`, `ChefPrincipal`, `Etudiant`, `Plat`, `MenuJour`, `Reservation`).
*   `services`: Contient la logique métier et la gestion de la persistance des données via des fichiers CSV.
    *   `FileService` (interface)
    *   `BaseFileService` (implémentation générique pour la lecture/écriture de fichiers CSV)
    *   `UserService`, `MenuService`, `ReservationService` (logique métier)
*   `ui`: Contient les classes JavaFX pour l'interface utilisateur (`LoginScene`, `ChefScene`, `EtudiantScene`).
*   `data/`: Contient les fichiers CSV pour la persistance des données : `users.csv`, `plats.csv`, `menu.csv`, `reservations.csv`.

## Prérequis

*   Java Development Kit (JDK) version 17 ou supérieure.
*   **Pour Eclipse :** Le projet est pré-configuré avec les fichiers `.project` et `.classpath` pour une importation directe.

## Importation et Exécution dans Eclipse

1.  **Dézipper l'archive** : Extrayez le contenu du fichier ZIP. Vous devriez obtenir un dossier nommé `restaurant_app`.
2.  **Importer le projet** :
    *   Dans Eclipse, allez dans `File` -> `Import...`.
    *   Sélectionnez `General` -> `Existing Projects into Workspace`.
    *   Cliquez sur `Next`.
    *   Cliquez sur `Browse...` à côté de `Select root directory:` et sélectionnez le dossier `restaurant_app` que vous venez d'extraire.
    *   Assurez-vous que le projet `restaurant_app` est coché.
    *   Cliquez sur `Finish`.
3.  **Vérification de JavaFX** : Le fichier `.classpath` est configuré pour utiliser les bibliothèques JavaFX installées sur un système Linux standard (`/usr/share/openjfx/lib`). Si vous utilisez un autre système d'exploitation ou si JavaFX n'est pas installé à cet emplacement, vous devrez peut-être reconfigurer le chemin des bibliothèques JavaFX dans les propriétés de construction du projet.
4.  **Exécution** :
    *   Faites un clic droit sur la classe `app.MainFX`.
    *   Sélectionnez `Run As` -> `Java Application`.

## Fichiers CSV pour la Persistance

Les données sont sauvegardées dans le répertoire `data/` :

*   `users.csv`: Contient les informations des étudiants (le chef principal est codé en dur).
*   `plats.csv`: Contient la liste de tous les plats uniques créés.
*   `menu.csv`: Contient la structure du menu de la semaine (référence aux IDs des plats).
*   `reservations.csv`: Contient l'historique des réservations, y compris le statut de prise de repas et la note.

## Identifiants de Test

| Rôle | Email | Mot de passe |
| :--- | :--- | :--- |
| **Chef Principal** | `chef.principal@ihec.ucar.tn` | `1234` |
| **Étudiant** | `nom.prenom.2024@ihec.ucar.tn` | `2024` |
| **(Création auto)** | (Ex: `nour.tkitek.2024@ihec.ucar.tn`) | (Ex: `2024`) |
