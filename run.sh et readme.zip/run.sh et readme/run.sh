#!/bin/bash
JAVAFX_SDK_PATH="./lib/javafx-sdk-25.0.1"
JAVAFX_MODULES="javafx.controls,javafx.fxml,javafx.graphics"
java --module-path "$JAVAFX_SDK_PATH/lib" --add-modules "$JAVAFX_MODULES" -cp out app.MainFX

